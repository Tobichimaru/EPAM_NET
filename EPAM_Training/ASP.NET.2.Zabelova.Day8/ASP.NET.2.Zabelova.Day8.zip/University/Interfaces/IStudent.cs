﻿using University.Classes;

namespace University.Interfaces
{
    /// <summary>
    /// Describes student interface
    /// </summary>
    public interface IStudent : IObserver<HomeTask>, INameId
    {
        #region Public Methods and Properties
        /// <summary>
        /// Generates homework to the specified task
        /// </summary>
        /// <param name="task">task to be completed</param>
        /// <returns>homework to the task</returns>
        HomeWork DoHomeWork(HomeTask task);
        #endregion

    }
}
