﻿using University.Interfaces;

namespace University.Classes
{
    /// <summary>
    /// Describes student
    /// </summary>
    public class Student : IStudent
    {
        #region Constructors
        static Student()
        {
            counter = 0;
            LoggerClass.Logger.Trace("static Student() called");
        }

        /// <summary>
        /// Initialize student instance
        /// </summary>
        /// <param name="name">name of student</param>
        public Student(string name)
        {
            counter++;
            Name = name;
            Id = counter;
            LoggerClass.Logger.Trace("Student (ID = " + Id + ", name = \"" + name + "\") initialized");
        }
        #endregion
        
        #region Public Methods and Properties
        public void Update(HomeTask task)
        {
            LoggerClass.Logger.Trace("Student.Update(HomeTask task)");
            LoggerClass.Logger.Info("Hometask from Course (ID = " + task.InitialCourse.Id +
                                    ") was recieved by Student (Id = " + Id + ")");
            LoggerClass.Logger.Debug("Hometask (title = \"" + task.Title + "\")" +
                                    "from Course (name = \"" + task.InitialCourse.Name + "\")" +
                                    "was recieved by Student (name = \"" + Name + "\")");

            task.InitialCourse.GetHomework(DoHomeWork(task), task);
        }

        public HomeWork DoHomeWork(HomeTask task)
        {
            LoggerClass.Logger.Trace("Student.DoHomeWork(HomeTask task)");
            HomeWork homework = new HomeWork(task.Title + " done!", task.Description, this);

            LoggerClass.Logger.Info("Hometask from Course (ID = " + task.InitialCourse.Id +
                                    ") was done by Student (Id = " + Id + ")");
            LoggerClass.Logger.Debug("Hometask (title = \"" + task.Title + "\")" +
                                    "from Course (name = \"" + task.InitialCourse.Name + "\")" +
                                    "was done by Student (name = \"" + Name + "\")." +
                                    "Homework (title = \"" + homework.Title + "\")");
            return homework;
        }

        public string Name { get; private set; }
        public int Id { get; private set; } 
        #endregion

        #region Private Fields and Properties
        private static int counter;
        #endregion

    }
}
