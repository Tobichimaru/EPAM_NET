﻿using System;
using University.Interfaces;

namespace University.Classes
{
    /// <summary>
    /// Describes professor 
    /// </summary>
    public class Professor : ICurator
    {
        #region Constructor
        static Professor()
        {
            LoggerClass.Logger.Trace("static Professor() called");
            counter = 0;
        }

        /// <summary>
        /// Initialize professor instance
        /// </summary>
        /// <param name="name">name of the professor</param>
        public Professor(string name)
        {
            counter++;
            Id = counter;
            Name = name;
            LoggerClass.Logger.Trace("Professor (ID = " + Id + ", name = \"" + name + "\") initialized");
        }
        #endregion

        #region Public Methods and Properties
        public int SetMark(IWork homeWork)
        {
            LoggerClass.Logger.Trace("Professor.SetMark(IWork homeWork)");
            Random rnd = new Random();
            int mark = rnd.Next(3, 9);
            
            LoggerClass.Logger.Info("Homework was recieved mark = " + mark);
            LoggerClass.Logger.Debug("Homework (title = \"" + homeWork.Title + "\") " +
                                     "was graded by Curator (ID = " + Id + ", name = \"" + Name +"\")" +
                                     "mark = " + mark);
            return mark;
        }

        public string Name { get; private set; }
        public int Id { get; private set; }

        #endregion

        #region Private Fields
        private static int counter;
        #endregion
    }
}
