﻿using University.Interfaces;

namespace University.Classes
{
    /// <summary>
    /// Describes student homework
    /// </summary>
    public class HomeWork : IWork
    {
        #region Constructor
        /// <summary>
        /// Initialize homework
        /// </summary>
        /// <param name="title">title of the homework</param>
        /// <param name="text">text of the homework</param>
        /// <param name="author">author of the homework</param>
        public HomeWork(string title, string text, IStudent author)
        {   
            Title = title;
            Description = text;
            StudentAuthor = author;

            LoggerClass.Logger.Trace("HomeWork (title = \"" + title + "\") initialized");
        }
        #endregion

        #region Properties
        public string Title { get; private set; }
        public string Description { get; private set; }

        /// <summary>
        /// Author of the homework
        /// </summary>
        public IStudent StudentAuthor { get; set; }
        #endregion
    }
}
