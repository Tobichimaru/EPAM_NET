﻿using System;
using System.Collections.Generic;
using University.Interfaces;

namespace University.Classes
{
    /// <summary>
    /// Desribes course 
    /// </summary>
    public class Course : ICourse
    {
        #region Constructors
        static Course()
        {
            LoggerClass.Logger.Trace("static Course() called");
            counter = 0;
        }

        /// <summary>
        /// Initializes course with custom name and curator
        /// </summary>
        /// <param name="name">name of the course</param>
        /// <param name="curator">curator of the course</param>
        public Course(string name, ICurator curator)
        {
            counter++;
            Id = counter;

            Name = name;
            this.curator = curator;
            students = new List<IStudent>();

            LoggerClass.Logger.Trace("Course (ID = " + Id + ", name = \"" + name + "\") initialized");
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Add student to the Course
        /// </summary>
        /// <param name="student">student</param>
        public void AddObserver(IStudent student)
        {
            LoggerClass.Logger.Trace("Course.AddObserver(IStudent student)");
            LoggerClass.Logger.Info("Course (ID = " + Id + ") adds observer (ID = " + student.Id + ")");
            LoggerClass.Logger.Debug("Course (name = \"" + Name + "\") adds observer (name = \"" + student.Name + "\")");

            if (!students.Contains(student))
                students.Add(student);
            else
                LoggerClass.Logger.Warn("Course already contains this Student");
        }

        public void AddObserver(Interfaces.IObserver<IWork> o)
        {
            LoggerClass.Logger.Trace("Course.AddObserver(IObserver<IWork> o)");
            IStudent student = CheckReference(o);
            AddObserver(student);
        }

        /// <summary>
        /// remove student from the course
        /// </summary>
        /// <param name="student">student</param>
        public void RemoveObserver(IStudent student)
        {
            LoggerClass.Logger.Trace("Course.RemoveObserver(IStudent student)");
            LoggerClass.Logger.Info("Course (ID = " + Id + ") removes observer (ID = " + student.Id + ")");
            LoggerClass.Logger.Debug("Course (name = \"" + Name + "\") removes observer (name = \"" + student.Name + "\")");

            if (!students.Contains(student))
                students.Remove(student);
            else
                LoggerClass.Logger.Warn("Course doesn't contains this Student");
        }

        public void RemoveObserver(Interfaces.IObserver<IWork> o)
        {
            LoggerClass.Logger.Trace("Course.RemoveObserver(IObserver<IWork> o)");
            IStudent student = CheckReference(o);
            RemoveObserver(student);
        }

        public void NotifyObservers(IWork info)
        {
            LoggerClass.Logger.Trace("Course.NotifyObservers(IWork info)");
            LoggerClass.Logger.Info("Course (ID = " + Id + ") notifies observers with task");
            LoggerClass.Logger.Debug("Course (name = \"" + Name + "\") notifies observers with task (name = \"" + info.Title + "\")");
            
            foreach (var student in students)
            {
                student.Update(new HomeTask(info.Title, info.Description, this));
            }
        }

        public void GetHomework(HomeWork homeWork, HomeTask task)
        {
            LoggerClass.Logger.Trace("Course.GetHomework(HomeWork homeWork, IWork task)");
            LoggerClass.Logger.Info("Homework on Task from Author (Id = " + homeWork.StudentAuthor.Id + ") was recieved by Course (Id = " + Id + ")");
            LoggerClass.Logger.Debug("Homework (title = \"" + homeWork.Title + "\") on Task (title =\"" + task.Title +
                "\") from Author (name = \"" + homeWork.StudentAuthor.Name + "\") was recieved by Course (name = \"" + Name + "\")");

            int mark = curator.SetMark(homeWork);
            Archive.Instance.RecordMark(homeWork.StudentAuthor, this, task, mark);
        }
        #endregion

        #region Public Properties
        public string Name { get; private set; }
        public int Id { get; private set; }
        #endregion

        #region Private Methods
        private IStudent CheckReference(Interfaces.IObserver<HomeWork> o)
        {
            IStudent student = o as IStudent;
            if (student == null)
            {
                LoggerClass.Logger.Error("Inputed interface is not IStudent. Course ID = " + Id);
                throw new NullReferenceException();
            }

            return student;
        }
        #endregion

        #region Private Fields
        private static int counter;
        private readonly List<IStudent> students;
        private readonly ICurator curator;
        #endregion

    } 
}
